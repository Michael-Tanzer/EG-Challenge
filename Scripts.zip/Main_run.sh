#!/usr/bin/env bash

./Data_Process.py
