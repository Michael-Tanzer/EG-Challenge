#!/usr/bin/env python3

import pandas as pd
import os
import seaborn as sns

path1=os.getcwd()
path0=os.path.dirname(path1)

DFrame=pd.read_csv(path0+'/coin_data.csv')
num=0
for region, df_Type in DFrame.groupby('currency'):
    num+=1
    #if str(region).lower()=='zcoin':
        #print(df_Type['close'])

print(num)
